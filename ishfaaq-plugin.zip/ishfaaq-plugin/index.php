<?php

die('Access Denied');